# Artefatos do projeto

Liste os artefatos produzidos, com suas localizaçãoes e descrição do conteúdo.


* `/data` - Pasta com os dados do projeto
* `/models` - Pasta com os modelos já induzidos
* `/results ` - Pasta com os resultados da análise exploratória de dados

