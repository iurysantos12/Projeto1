# Resultados

* Gráficos e imagens da análise exploratória de dados



