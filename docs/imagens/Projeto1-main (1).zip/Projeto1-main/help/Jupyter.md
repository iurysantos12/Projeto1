# Jupyter Notebook
Para instalação do Jupyter Notebook é preciso instalar o Pacote Anaconda.
É possivel fazer a instalação pelo link: [Anaconda](https://www.anaconda.com/)

Após a instalação basta procurar por "Jupyter Notebook" em seus aplicativos.

- Links úteis:
  - [Instalando Jupyter Notebook](https://www.hashtagtreinamentos.com/instalar-pacote-anaconda-jupyter-python)
  - [Instalando Jupyter Notebook(Vídeo)](https://www.youtube.com/watch?v=_eK0z5QbpKA)

