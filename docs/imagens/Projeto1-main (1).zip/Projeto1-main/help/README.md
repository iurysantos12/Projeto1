# Material de Apoio


- Instruções sobre o uso do Github e Github Classroom: [Github](github.md)
- [GitHub Classroom - Instruções para alunos.pdf](https://github.com/ICEI-PUC-Minas-PMV-SI/WebApplicationProject-Template/blob/main/help/GitHub%20Classroom%20-%20Instru%C3%A7%C3%B5es%20para%20alunos.pdf)
- Instruções sobre cadastros de dados usando *Local Storage* ou o *Json-server*: [Persistência](persistencia.md)
- Instruções sobre preenchimento do arquivo CITATION.cff: [Citation](citation.md)
>>>>>>> af30dcaf4fbbfe15eddce8d0ea9b00bbd977a47a
